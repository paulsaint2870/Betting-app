package com.paulsaint.verdict

import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import kotlin.math.abs
import kotlin.math.exp
import kotlin.math.roundToInt

// ---------- MODEL ----------
val FACTORS = listOf(
    "Strength (xG/Elo/market)" to 0.30, "Recent form" to 0.25, "Squad news" to 0.15,
    "Standings & motivation" to 0.10, "Head-to-head" to 0.10, "Context (rest/travel)" to 0.10
)
val KEYS = listOf("strength", "form", "squad", "standings", "head_to_head", "context")

data class Match(
    val id: Long, val home: String, val away: String, val f: List<Float>,
    val oh: Double?, val od: Double?, val oa: Double?,
    val sport: Int = 0, val total: Float = 2.7f, val line: Double = 2.5   // sport 0 = football, 1 = basketball
)

data class Verdict(
    val pH: Double, val pD: Double, val pA: Double, val pick: String, val pickP: Double,
    val confidence: Double, val edge: Double?, val call: String, val safer: String,
    val driver: String, val against: String, val rank: Double,
    val score: String, val scoreP: Double?, val scoreConf: Double,
    val goalsPick: String, val goalsP: Double, val goalsConf: Double, val goalsCall: String,
    val extra: String
)

object Store { val matches = mutableStateListOf<Match>() }

fun poisson(l: Double, k: Int): Double { var p = exp(-l); for (i in 1..k) p *= l / i; return p }
fun phi(x: Double): Double {
    val t = 1 / (1 + 0.2316419 * abs(x)); val d = 0.3989423 * exp(-x * x / 2)
    val p = d * t * (0.3193815 + t * (-0.3565638 + t * (1.781478 + t * (-1.821256 + t * 1.330274))))
    return if (x > 0) 1 - p else p
}
fun fmt(d: Double) = if (d == d.toLong().toDouble()) d.toLong().toString() else "%.1f".format(d)

// ---------- ENGINE (30/25/15/10/10/10 weights) ----------
fun analyze(m: Match): Verdict {
    val basket = m.sport == 1
    val sig = m.f.map { (it - 50f) / 50.0 }               // -1 (away) .. +1 (home)
    val contrib = FACTORS.indices.map { FACTORS[it].second * sig[it] }
    val s = contrib.sum()
    val pd = if (basket) 0.0 else 0.28 - 0.08 * abs(s)
    val share = 1 / (1 + exp(-2.5 * s))
    val pH = (1 - pd) * share
    val pA = (1 - pd) * (1 - share)
    val probs = listOf(pH, pd, pA)
    val names = listOf(m.home.ifBlank { "Home" }, "Draw", m.away.ifBlank { "Away" })
    val idx = probs.indices.maxByOrNull { probs[it] }!!
    val pickP = probs[idx]

    val active = FACTORS.indices.filter { sig[it] != 0.0 }
    val totalW = active.sumOf { FACTORS[it].second }
    val agreeW = active.filter { sig[it] * s > 0 }.sumOf { FACTORS[it].second }
    val agree = if (totalW == 0.0) 0.0 else agreeW / totalW
    val conf = agree * (0.5 + 0.5 * minOf(1.0, abs(s) * 2))

    var edge: Double? = null
    if (!basket && m.oh != null && m.od != null && m.oa != null && m.oh > 1 && m.od > 1 && m.oa > 1) {
        val raw = listOf(1 / m.oh, 1 / m.od, 1 / m.oa)
        edge = pickP - raw[idx] / raw.sum()                  // vs de-vigged market
    }
    val call = when {
        edge != null && edge >= 0.05 && pickP >= 0.45 && conf >= 0.6 -> "BET"
        (pickP >= 0.50 && conf >= 0.5) || (edge != null && edge >= 0.03 && conf >= 0.5) -> "LEAN"
        else -> "NO BET"
    }
    val safer = when {
        basket -> "No safer market"
        idx == 0 -> "${names[0]} or Draw (${pct(pH + pd)})"
        idx == 2 -> "Draw or ${names[2]} (${pct(pA + pd)})"
        else -> "No safer market"
    }
    val driverI = contrib.indices.maxByOrNull { contrib[it] * (if (s >= 0) 1 else -1) }!!
    val againstI = contrib.indices.minByOrNull { contrib[it] * (if (s >= 0) 1 else -1) }!!
    val against = if (contrib[againstI] * s < 0) FACTORS[againstI].first else "None – all factors agree"

    // ----- scoreline + over/under -----
    val tot = m.total.toDouble()
    val pOver: Double
    val score: String
    var scoreP: Double? = null
    var extra = ""
    if (!basket) {
        val hShare = (0.53 + 0.22 * s).coerceIn(0.25, 0.75)
        val lh = tot * hShare; val la = tot - lh
        var best = -1.0; var bi = 0; var bj = 0; var over = 0.0; var o15 = 0.0; var btts = 0.0
        for (i in 0..9) for (j in 0..9) {
            val p = poisson(lh, i) * poisson(la, j)
            if (i + j > m.line) over += p
            if (i + j >= 2) o15 += p
            if (i > 0 && j > 0) btts += p
            val matches = (idx == 0 && i > j) || (idx == 1 && i == j) || (idx == 2 && i < j)
            if (matches && p > best) { best = p; bi = i; bj = j }
        }
        pOver = over; score = "$bi-$bj"; scoreP = best
        extra = "Over 1.5: ${pct(o15)} · Both teams score: ${pct(btts)}"
    } else {
        val margin = s * 14
        val h = (tot + margin) / 2; val a = (tot - margin) / 2
        score = "${h.roundToInt()}-${a.roundToInt()}"
        pOver = 1 - phi((m.line - tot) / 18.0)
        extra = "Projected margin: ${"%+.1f".format(margin)} pts (home)"
    }
    val gOver = pOver >= 0.5
    val gP = if (gOver) pOver else 1 - pOver
    val gConf = (0.5 + 0.5 * agree) * minOf(1.0, abs(gP - 0.5) * 4)
    val gCall = if (gP >= 0.58 && gConf >= 0.4) "LEAN" else "NO BET"
    val sConf = if (scoreP != null) (0.5 + 0.5 * agree) * minOf(1.0, scoreP / 0.15) else (0.5 + 0.5 * agree) * 0.5
    return Verdict(pH, pd, pA, names[idx], pickP, conf, edge, call, safer,
        FACTORS[driverI].first, against, pickP * conf,
        score, scoreP, sConf,
        (if (gOver) "Over " else "Under ") + fmt(m.line), gP, gConf, gCall, extra)
}

fun pct(p: Double) = "${(p * 100).roundToInt()}%"

// ---------- AI (Anthropic API + web search) ----------
suspend fun aiSuggest(key: String, home: String, away: String, sport: Int): List<Float>? = withContext(Dispatchers.IO) {
    try {
        val unit = if (sport == 0) "total goals (0.5-6)" else "total points (160-280)"
        val prompt = "Search the web for the latest on $home vs $away (form, standings, " +
            "head-to-head, injuries, lineups, odds). Rate each factor 0-100 from the HOME team's " +
            "perspective (50 = even, higher favors home), and give the expected $unit. Reply with ONLY JSON: " +
            "{\"strength\":n,\"form\":n,\"squad\":n,\"standings\":n,\"head_to_head\":n,\"context\":n,\"total\":n}"
        val body = JSONObject().put("model", "claude-sonnet-5-5").put("max_tokens", 1000)
            .put("tools", JSONArray().put(JSONObject().put("type", "web_search_20250305").put("name", "web_search")))
            .put("messages", JSONArray().put(JSONObject().put("role", "user").put("content", prompt)))
        val c = URL("https://api.anthropic.com/v1/messages").openConnection() as HttpURLConnection
        c.requestMethod = "POST"; c.doOutput = true; c.readTimeout = 90000
        c.setRequestProperty("content-type", "application/json")
        c.setRequestProperty("x-api-key", key)
        c.setRequestProperty("anthropic-version", "2023-06-01")
        c.outputStream.use { it.write(body.toString().toByteArray()) }
        if (c.responseCode != 200) return@withContext null
        val content = JSONObject(c.inputStream.bufferedReader().readText()).getJSONArray("content")
        val text = (0 until content.length()).map { content.getJSONObject(it) }
            .filter { it.optString("type") == "text" }.joinToString("") { it.getString("text") }
        val j = JSONObject(text.substring(text.indexOf('{'), text.lastIndexOf('}') + 1))
        val out = KEYS.map { j.getDouble(it).coerceIn(0.0, 100.0).toFloat() }.toMutableList()
        val t = j.getDouble("total")
        out.add((if (sport == 0) t.coerceIn(0.5, 6.0) else t.coerceIn(160.0, 280.0)).toFloat())
        out
    } catch (e: Exception) { null }
}

// ---------- UI ----------
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme(colorScheme = lightColorScheme()) { App() } }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun App() {
    var tab by rememberSaveable { mutableIntStateOf(0) }
    Scaffold(
        topBar = { TopAppBar(title = { Text("Verdict") }) },
        bottomBar = {
            NavigationBar {
                NavigationBarItem(tab == 0, { tab = 0 }, { Icon(Icons.Default.Edit, null) }, label = { Text("Analyze") })
                NavigationBarItem(tab == 1, { tab = 1 }, { Icon(Icons.Default.Star, null) }, label = { Text("Picks") })
                NavigationBarItem(tab == 2, { tab = 2 }, { Icon(Icons.Default.Settings, null) }, label = { Text("Settings") })
            }
        }
    ) { pad ->
        Box(Modifier.padding(pad).padding(horizontal = 16.dp)) {
            when (tab) {
                0 -> AnalyzeScreen { tab = 1 }
                1 -> PicksScreen()
                else -> SettingsScreen()
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AnalyzeScreen(onSaved: () -> Unit) {
    val ctx = androidx.compose.ui.platform.LocalContext.current
    val scope = rememberCoroutineScope()
    var home by remember { mutableStateOf("") }
    var away by remember { mutableStateOf("") }
    val f = remember { mutableStateListOf(50f, 50f, 50f, 50f, 50f, 50f) }
    var oh by remember { mutableStateOf("") }
    var od by remember { mutableStateOf("") }
    var oa by remember { mutableStateOf("") }
    var status by remember { mutableStateOf("") }
    var loading by remember { mutableStateOf(false) }
    var sport by remember { mutableIntStateOf(0) }
    var total by remember { mutableFloatStateOf(2.7f) }
    var line by remember { mutableStateOf("2.5") }
    val draft = Match(0, home, away, f.toList(), oh.toDoubleOrNull(), od.toDoubleOrNull(), oa.toDoubleOrNull(),
        sport, total, line.toDoubleOrNull() ?: if (sport == 0) 2.5 else 220.5)

    Column(Modifier.verticalScroll(rememberScrollState()).padding(vertical = 8.dp)) {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(sport == 0, { sport = 0; total = 2.7f; line = "2.5" }, { Text("Football (goals)") })
            FilterChip(sport == 1, { sport = 1; total = 220f; line = "220.5" }, { Text("Basketball (points)") })
        }
        OutlinedTextField(home, { home = it }, label = { Text("Home team") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(away, { away = it }, label = { Text("Away team") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        Button(
            enabled = !loading && home.isNotBlank() && away.isNotBlank(),
            onClick = {
                val key = ctx.getSharedPreferences("v", Context.MODE_PRIVATE).getString("key", "") ?: ""
                if (key.isBlank()) { status = "Add your API key in Settings first."; return@Button }
                scope.launch {
                    loading = true; status = "Searching and rating factors…"
                    val r = aiSuggest(key, home, away, sport)
                    if (r != null) { for (i in 0..5) f[i] = r[i]; total = r[6]; status = "AI filled the factors. Adjust if you disagree." }
                    else status = "AI request failed. Check key/connection or set sliders manually."
                    loading = false
                }
            },
            modifier = Modifier.fillMaxWidth().padding(top = 8.dp)
        ) { Text(if (loading) "Working…" else "AI auto-fill factors") }
        if (status.isNotEmpty()) Text(status, style = MaterialTheme.typography.bodySmall)

        Text("Factors (50 = even, right = favors home)", fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 12.dp))
        FACTORS.forEachIndexed { i, (name, w) ->
            Text("$name · ${(w * 100).roundToInt()}% weight · ${f[i].roundToInt()}")
            Slider(f[i], { f[i] = it }, valueRange = 0f..100f)
        }
        Text("Expected ${if (sport == 0) "goals" else "points"}: ${"%.1f".format(total)}", fontWeight = FontWeight.Bold)
        Slider(total, { total = it }, valueRange = if (sport == 0) 0.5f..6f else 160f..280f)
        OutlinedTextField(line, { line = it }, label = { Text("Over/Under line") }, singleLine = true, modifier = Modifier.fillMaxWidth(),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal))
        Text("Market odds (optional, decimal)", fontWeight = FontWeight.Bold)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            for ((label, get, set) in listOf(Triple("Home", oh, { s: String -> oh = s }),
                Triple("Draw", od, { s: String -> od = s }), Triple("Away", oa, { s: String -> oa = s }))) {
                OutlinedTextField(get, set, label = { Text(label) }, singleLine = true, modifier = Modifier.weight(1f),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal))
            }
        }
        VerdictCard(draft, analyze(draft), null)
        Button(
            enabled = home.isNotBlank() && away.isNotBlank(),
            onClick = { Store.matches.add(draft.copy(id = System.nanoTime())); onSaved() },
            modifier = Modifier.fillMaxWidth()
        ) { Text("Save to Picks") }
        Spacer(Modifier.height(24.dp))
    }
}

@Composable
fun PicksScreen() {
    val ranked = Store.matches.map { it to analyze(it) }.sortedByDescending { it.second.rank }
    if (ranked.isEmpty()) {
        Box(Modifier.fillMaxSize(), Alignment.Center) { Text("No picks yet. Analyze a match first.") }
        return
    }
    LazyColumn {
        item { Text("Ranked by probability × confidence", style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(top = 8.dp)) }
        items(ranked, key = { it.first.id }) { (m, v) -> VerdictCard(m, v) { Store.matches.remove(m) } }
    }
}

@Composable
fun SettingsScreen() {
    val ctx = androidx.compose.ui.platform.LocalContext.current
    val prefs = ctx.getSharedPreferences("v", Context.MODE_PRIVATE)
    var key by remember { mutableStateOf(prefs.getString("key", "") ?: "") }
    Column(Modifier.padding(vertical = 8.dp)) {
        OutlinedTextField(key, { key = it; prefs.edit().putString("key", it).apply() },
            label = { Text("Anthropic API key") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        Text("Key is stored only on this phone. It powers the AI auto-fill button.", style = MaterialTheme.typography.bodySmall)
        Text("\nThis app gives probability estimates, not guarantees. No model reliably hits 82-89% on match results. " +
            "Re-check lineups before kickoff and never stake money you can't afford to lose.", style = MaterialTheme.typography.bodySmall)
    }
}

@Composable
fun VerdictCard(m: Match, v: Verdict, onDelete: (() -> Unit)?) {
    val callColor = when (v.call) { "BET" -> Color(0xFF2E7D32); "LEAN" -> Color(0xFFEF6C00); else -> Color(0xFFC62828) }
    Card(Modifier.fillMaxWidth().padding(vertical = 8.dp)) {
        Column(Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("${m.home.ifBlank { "Home" }} vs ${m.away.ifBlank { "Away" }}", fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                Text(v.call, color = callColor, fontWeight = FontWeight.ExtraBold)
                if (onDelete != null) IconButton(onDelete) { Icon(Icons.Default.Delete, "Delete") }
            }
            ProbRow("Home", v.pH); ProbRow("Draw", v.pD); ProbRow("Away", v.pA)
            Text("Pick: ${v.pick} (${pct(v.pickP)}) · Confidence ${pct(v.confidence)}", fontWeight = FontWeight.Medium, modifier = Modifier.padding(top = 8.dp))
            Text(v.edge?.let { "Edge vs market: ${"%+.1f".format(it * 100)} pts" } ?: "Edge vs market: add odds to see it")
            Text("Main driver: ${v.driver}")
            Text("Strongest case against: ${v.against}")
            Text("Safer market: ${v.safer}")
            Divider(Modifier.padding(vertical = 8.dp))
            Text(if (m.sport == 0) "Scoreline & goals" else "Score & points", fontWeight = FontWeight.Bold)
            Text("Scoreline: ${m.home.ifBlank { "Home" }} ${v.score} ${m.away.ifBlank { "Away" }}" +
                (v.scoreP?.let { " (${pct(it)} exact)" } ?: " (projected)") + " · Confidence ${pct(v.scoreConf)}")
            Row {
                Text("${v.goalsPick}: ${pct(v.goalsP)} · Confidence ${pct(v.goalsConf)}", Modifier.weight(1f))
                Text(v.goalsCall, fontWeight = FontWeight.Bold,
                    color = if (v.goalsCall == "LEAN") Color(0xFFEF6C00) else Color(0xFFC62828))
            }
            Text(v.extra, style = MaterialTheme.typography.bodySmall)
            Text("Would change it: lineup or injury news before kickoff", style = MaterialTheme.typography.bodySmall)
        }
    }
}

@Composable
fun ProbRow(label: String, p: Double) {
    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(top = 4.dp)) {
        Text(label, Modifier.width(48.dp))
        LinearProgressIndicator(progress = { p.toFloat() }, modifier = Modifier.weight(1f).padding(horizontal = 8.dp))
        Text(pct(p))
    }
}
